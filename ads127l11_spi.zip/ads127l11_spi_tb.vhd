-- =============================================================================
-- Self-checking testbench for ads127l11_spi (single channel)
-- Simulates:
--   1. Power-on reset
--   2. Register write (WREG to MODE register 0x02)
--   3. Register read  (RREG from MODE register 0x02)
--   4. 5 continuous ADC data reads triggered by DRDY
--   5. Checks every bit of received data is correct
-- =============================================================================
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity ads127l11_spi_tb is
end entity;

architecture sim of ads127l11_spi_tb is

    -- Clock period 25 MHz
    constant CLK_PERIOD : time := 40 ns;
    constant FRAME_BITS : integer := 32;

    -- DUT signals
    signal clk             : std_logic := '0';
    signal rst_n           : std_logic := '0';
    signal sclk            : std_logic;
    signal cs_n            : std_logic;
    signal sdi             : std_logic;
    signal sdo             : std_logic := '0';
    signal drdy_n          : std_logic := '1';
    signal adc_data        : std_logic_vector(23 downto 0);
    signal status_byte     : std_logic_vector(7  downto 0);
    signal data_valid      : std_logic;
    signal sample_count    : std_logic_vector(31 downto 0);
    signal reg_addr        : std_logic_vector(4  downto 0) := (others => '0');
    signal reg_wdata       : std_logic_vector(7  downto 0) := (others => '0');
    signal reg_rdata       : std_logic_vector(7  downto 0);
    signal reg_rdata_valid : std_logic;
    signal reg_wr_en       : std_logic := '0';
    signal reg_rd_en       : std_logic := '0';
    signal busy            : std_logic;

    -- Testbench internals
    signal tb_sdi_capture  : std_logic_vector(31 downto 0) := (others => '0');
    signal test_pass       : integer := 0;
    signal test_fail       : integer := 0;

    -- ADC model: shift register for SDO driving
    signal adc_tx_reg      : std_logic_vector(31 downto 0) := (others => '0');

begin

    -- =========================================================================
    -- DUT instantiation
    -- =========================================================================
    DUT : entity work.ads127l11_spi
        generic map (FRAME_BITS => FRAME_BITS)
        port map (
            clk             => clk,
            rst_n           => rst_n,
            sclk            => sclk,
            cs_n            => cs_n,
            sdi             => sdi,
            sdo             => sdo,
            drdy_n          => drdy_n,
            adc_data        => adc_data,
            status_byte     => status_byte,
            data_valid      => data_valid,
            sample_count    => sample_count,
            reg_addr        => reg_addr,
            reg_wdata       => reg_wdata,
            reg_rdata       => reg_rdata,
            reg_rdata_valid => reg_rdata_valid,
            reg_wr_en       => reg_wr_en,
            reg_rd_en       => reg_rd_en,
            busy            => busy
        );

    -- =========================================================================
    -- Clock generation: 25 MHz
    -- =========================================================================
    clk <= not clk after CLK_PERIOD/2;

    -- =========================================================================
    -- ADC model: drives SDO on every SCLK RISING edge (CPHA=1)
    -- Captures SDI on every SCLK FALLING edge
    -- =========================================================================
    p_adc_model : process
    begin
        wait until falling_edge(cs_n);  -- CS asserted
        -- Shift out adc_tx_reg MSB first on each SCLK rising edge
        for i in 31 downto 0 loop
            wait until rising_edge(sclk);
            sdo <= adc_tx_reg(i);
            -- Capture SDI on falling edge
            wait until falling_edge(sclk);
            tb_sdi_capture(i) <= sdi;
        end loop;
        sdo <= '0';
    end process;

    -- =========================================================================
    -- Main test sequence
    -- =========================================================================
    p_test : process

        procedure wait_clk(n : integer) is
        begin
            for i in 1 to n loop
                wait until rising_edge(clk);
            end loop;
        end procedure;

        procedure check(name : string; got : std_logic_vector; exp : std_logic_vector) is
        begin
            if got = exp then
                report "PASS: " & name & " = 0x" & 
                       integer'image(to_integer(unsigned(got))) severity note;
                test_pass <= test_pass + 1;
            else
                report "FAIL: " & name & 
                       " expected 0x" & integer'image(to_integer(unsigned(exp))) &
                       " got 0x"      & integer'image(to_integer(unsigned(got)))
                       severity error;
                test_fail <= test_fail + 1;
            end if;
        end procedure;

    begin
        -- ----------------------------------------------------------------
        -- 1. RESET
        -- ----------------------------------------------------------------
        report "=== TEST 1: Power-on reset ===" severity note;
        rst_n  <= '0';
        drdy_n <= '1';
        wait_clk(10);
        rst_n <= '1';
        wait_clk(5);

        -- Check outputs after reset
        assert cs_n   = '1' report "FAIL: cs_n not deasserted after reset"   severity error;
        assert sclk   = '0' report "FAIL: sclk not low after reset"          severity error;
        assert busy   = '0' report "FAIL: busy asserted after reset"         severity error;
        assert data_valid = '0' report "FAIL: data_valid asserted after reset" severity error;
        report "PASS: Reset outputs all correct" severity note;

        -- ----------------------------------------------------------------
        -- 2. REGISTER WRITE - WREG to MODE register (addr=0x02, data=0x06)
        --    Expected TX frame: {0x82, 0x00, 0x00, 0x06}
        --    = 1000_0010_0000_0000_0000_0000_0000_0110
        -- ----------------------------------------------------------------
        report "=== TEST 2: Register Write (WREG addr=0x02 data=0x06) ===" severity note;

        -- ADC will echo back a dummy status+data frame
        adc_tx_reg <= x"05000000";  -- status=0x05, data=0x000000

        reg_addr  <= "00010";  -- 0x02
        reg_wdata <= x"06";
        reg_wr_en <= '1';
        wait_clk(1);
        reg_wr_en <= '0';

        -- Wait for transaction to complete
        wait until busy = '0';
        wait_clk(2);

        -- Check FPGA drove correct command to ADC (captured by adc model)
        check("WREG cmd byte",  tb_sdi_capture(31 downto 24), x"82");
        check("WREG pad byte1", tb_sdi_capture(23 downto 16), x"00");
        check("WREG pad byte2", tb_sdi_capture(15 downto  8), x"00");
        check("WREG data byte", tb_sdi_capture( 7 downto  0), x"06");

        -- ----------------------------------------------------------------
        -- 3. REGISTER READ - RREG from MODE register (addr=0x02)
        --    Expected TX frame 1: {0x22, 0x00, 0x00, 0x00}
        --    Expected TX frame 2: {0x00, 0x00, 0x00, 0x00} NOP
        --    ADC returns register value in frame 2 byte[0]
        -- ----------------------------------------------------------------
        report "=== TEST 3: Register Read (RREG addr=0x02) ===" severity note;

        -- Frame 1: ADC echoes status
        adc_tx_reg <= x"05000000";

        reg_addr  <= "00010";  -- 0x02
        reg_rd_en <= '1';
        wait_clk(1);
        reg_rd_en <= '0';

        -- Wait for CS to go low (frame 1 starting)
        wait until cs_n = '0';
        wait until cs_n = '1';  -- frame 1 done

        -- Check RREG command was correct
        check("RREG cmd byte",  tb_sdi_capture(31 downto 24), x"22");
        check("RREG pad bytes", tb_sdi_capture(23 downto  0), x"000000");

        -- Frame 2 (NOP readback): ADC returns reg value in LSByte
        adc_tx_reg <= x"00000006";  -- register returns 0x06 (what we wrote)

        -- Wait for CS gap then frame 2 to complete
        wait until cs_n = '0';
        wait until cs_n = '1';
        wait_clk(3);

        check("RREG readback data", reg_rdata, x"06");
        assert reg_rdata_valid = '0' report "FAIL: reg_rdata_valid not pulsed" severity error;

        -- ----------------------------------------------------------------
        -- 4. CONTINUOUS ADC DATA READ - 5 samples
        -- ----------------------------------------------------------------
        report "=== TEST 4: Continuous ADC data read (5 samples) ===" severity note;

        for sample in 1 to 5 loop
            -- ADC asserts DRDY (low pulse ~1 µs = 25 clk cycles)
            -- Each sample has unique data: status=0xA0|sample, data=0x123400+sample
            -- Fixed pattern per sample:
            case sample is
                when 1 => adc_tx_reg <= x"A1AABBCC";
                when 2 => adc_tx_reg <= x"A2112233";
                when 3 => adc_tx_reg <= x"A3DEAD00";
                when 4 => adc_tx_reg <= x"A4CAFE01";
                when 5 => adc_tx_reg <= x"A5123456";
                when others => null;
            end case;

            drdy_n <= '0';   -- assert DRDY
            wait_clk(5);
            drdy_n <= '1';   -- deassert (pulse)

            -- Wait for data_valid pulse
            wait until data_valid = '1';
            wait until rising_edge(clk);

            -- Check received data matches what ADC sent
            case sample is
                when 1 =>
                    check("Sample1 status", status_byte, x"A1");
                    check("Sample1 data",   adc_data,   x"AABBCC");
                when 2 =>
                    check("Sample2 status", status_byte, x"A2");
                    check("Sample2 data",   adc_data,   x"112233");
                when 3 =>
                    check("Sample3 status", status_byte, x"A3");
                    check("Sample3 data",   adc_data,   x"DEAD00");
                when 4 =>
                    check("Sample4 status", status_byte, x"A4");
                    check("Sample4 data",   adc_data,   x"CAFE01");
                when 5 =>
                    check("Sample5 status", status_byte, x"A5");
                    check("Sample5 data",   adc_data,   x"123456");
                when others => null;
            end case;

            -- Check sample_count increments
            assert to_integer(unsigned(sample_count)) = sample
                report "FAIL: sample_count=" &
                       integer'image(to_integer(unsigned(sample_count))) &
                       " expected " & integer'image(sample)
                severity error;

            -- Check data_valid goes low next cycle (must be 1-cycle pulse)
            wait until rising_edge(clk);
            assert data_valid = '0'
                report "FAIL: data_valid did not deassert after 1 cycle" severity error;

            wait_clk(10);
        end loop;

        -- ----------------------------------------------------------------
        -- 5. TIMING CHECK - CS must be high between samples
        -- ----------------------------------------------------------------
        report "=== TEST 5: CS deasserted between samples ===" severity note;
        assert cs_n = '1'
            report "FAIL: CS still low between samples" severity error;
        assert sclk = '0'
            report "FAIL: SCLK not idle low between samples" severity error;
        report "PASS: CS and SCLK idle correctly between samples" severity note;

        -- ----------------------------------------------------------------
        -- 6. BUSY CHECK - busy must be low in idle
        -- ----------------------------------------------------------------
        assert busy = '0'
            report "FAIL: busy asserted in idle" severity error;
        report "PASS: busy deasserted in idle" severity note;

        -- ----------------------------------------------------------------
        -- Final report
        -- ----------------------------------------------------------------
        wait_clk(10);
        report "==================================================" severity note;
        report "SIMULATION COMPLETE" severity note;
        report "PASS: " & integer'image(test_pass) severity note;
        report "FAIL: " & integer'image(test_fail) severity note;
        if test_fail = 0 then
            report "ALL TESTS PASSED - safe to upload to FPGA" severity note;
        else
            report "TESTS FAILED - do NOT upload" severity failure;
        end if;

        wait;
    end process;

end architecture sim;
