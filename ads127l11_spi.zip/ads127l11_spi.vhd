-- =============================================================================
-- ADS127L11 SPI Master Controller  (FIXED v2)
-- =============================================================================
-- Device   : ADS127L11 400-kSPS 24-bit Delta-Sigma ADC (Texas Instruments)
-- FPGA Clk : 25 MHz — NO clock divider
--            SCLK = 12.5 MHz  (one SCLK cycle = 2 clk cycles = 80 ns)
--
-- SPI Mode : CPOL=0, CPHA=1  (Mode 1)
--   CPOL=0 → SCLK idles LOW
--   CPHA=1 → master drives SDI on rising  edge of SCLK
--            master samples SDO on falling edge of SCLK
--
-- KEY TIMING INSIGHT — registered outputs add 1-cycle pipeline delay:
--
--   All signal assignments (sclk_r, sdi_r, sdo_reg) are REGISTERED.
--   They appear on the output pin ONE clock cycle AFTER the assignment.
--
--   Cycle N   : FSM runs rising-edge branch → sets sclk_r='1', sdi_r=tx[31]
--   Cycle N+1 : SCLK pin goes HIGH, SDI pin shows tx[31]
--               ADC sees rising edge, latches SDI, begins driving SDO
--   Cycle N+1 : FSM runs falling-edge branch → sets sclk_r='0'
--                                            → sdo_reg <= sdo   ← capture HERE
--               sdo from ADC is valid: ADC had all of cycle N+1 to settle it
--   Cycle N+2 : SCLK pin goes LOW
--               FSM samples sdo_reg into rx_shift ← stable, correct
--
--   Therefore:
--     sdo_reg must be captured in the FALLING-EDGE branch (sclk_phase='1')
--     NOT in the rising-edge branch as previous versions incorrectly did.
--
-- FRAME FORMAT (32-bit, STATUS_EN=1 default):
--   TX: bits[31:24]=command, bits[23:0]=data (NOP=all zeros for ADC read)
--   RX: bits[31:24]=status,  bits[23:0]=24-bit ADC conversion result
--
-- CONTINUOUS STREAMING:
--   drdy_n falling edge latched by drdy_flag even when FSM is busy.
--   FSM services it immediately on return to IDLE — no samples missed.
--
-- REGISTER ACCESS:
--   Write: 1 frame  {0x80|addr, 0x00, 0x00, wdata}   -- FIX1: was 0x40 (wrong)
--   Read : 2 frames — RREG cmd frame then NOP readback (CS-high gap between)
-- =============================================================================

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity ads127l11_spi is
    generic (
        FRAME_BITS : integer := 32
    );
    port (
        clk             : in  std_logic;
        rst_n           : in  std_logic;

        -- SPI pins
        sclk            : out std_logic;
        cs_n            : out std_logic;
        sdi             : out std_logic;
        sdo             : in  std_logic;
        drdy_n          : in  std_logic;

        -- ADC conversion data
        adc_data        : out std_logic_vector(23 downto 0);
        status_byte     : out std_logic_vector(7  downto 0);
        data_valid      : out std_logic;
        sample_count    : out std_logic_vector(31 downto 0);

        -- Register access
        reg_addr        : in  std_logic_vector(4 downto 0);
        reg_wdata       : in  std_logic_vector(7 downto 0);
        reg_rdata       : out std_logic_vector(7 downto 0);
        reg_rdata_valid : out std_logic;
        reg_wr_en       : in  std_logic;
        reg_rd_en       : in  std_logic;

        busy            : out std_logic
    );
end entity ads127l11_spi;

architecture rtl of ads127l11_spi is

    type t_state is (
        ST_IDLE,
        ST_CS_SETUP,
        ST_SHIFT,
        ST_CS_HOLD,
        ST_DONE,
        ST_RREG_GAP,
        ST_CS_SETUP2,
        ST_SHIFT2,
        ST_CS_HOLD2,
        ST_DONE2
    );
    type t_op is (OP_ADC_READ, OP_REG_WR, OP_REG_RD);

    signal state        : t_state := ST_IDLE;
    signal current_op   : t_op    := OP_ADC_READ;

    -- DRDY synchroniser
    signal drdy_sync1   : std_logic := '1';
    signal drdy_sync2   : std_logic := '1';
    signal drdy_prev    : std_logic := '1';
    signal drdy_flag    : std_logic := '0';

    -- SPI output registers
    signal sclk_r       : std_logic := '0';
    signal cs_n_r       : std_logic := '1';
    signal sdi_r        : std_logic := '0';

    -- Shift registers
    signal tx_shift     : std_logic_vector(FRAME_BITS-1 downto 0) := (others => '0');
    signal rx_shift     : std_logic_vector(FRAME_BITS-1 downto 0) := (others => '0');

    -- 1-bit SCLK phase toggle
    -- '0' = next action is a RISING  edge (sclk_r → '1')
    -- '1' = next action is a FALLING edge (sclk_r → '0')
    signal sclk_phase   : std_logic := '0';

    -- Bit counter (FRAME_BITS down to 1, decremented on each falling edge)
    signal bit_cnt      : integer range 0 to FRAME_BITS := 0;

    -- Inter-frame gap counter
    -- FIX4: 5 cycles @ 25 MHz = 200 ns CS-high gap between RREG frames.
    -- ADS127L11 requires min 1 SCLK period (80 ns). 200 ns gives 2.5x margin.
    signal gap_cnt      : integer range 0 to 5 := 0;

    -- sdo_reg removed (FIX3): sdo is sampled directly into rx_shift in the
    -- falling-edge branch. No pipeline register needed at 25 MHz / 12.5 MHz SCLK
    -- because ADC SDO prop delay (~20 ns max) << clk period (40 ns).

    -- Output registers
    signal adc_data_r        : std_logic_vector(23 downto 0) := (others => '0');
    signal status_byte_r     : std_logic_vector(7  downto 0) := (others => '0');
    signal data_valid_r      : std_logic := '0';
    signal sample_count_r    : unsigned(31 downto 0) := (others => '0');
    signal reg_rdata_r       : std_logic_vector(7  downto 0) := (others => '0');
    signal reg_rdata_valid_r : std_logic := '0';

begin

    -- =========================================================================
    -- DRDY 2-FF synchroniser + falling-edge flag
    -- =========================================================================
    p_drdy : process(clk, rst_n)
    begin
        if rst_n = '0' then
            drdy_sync1 <= '1';
            drdy_sync2 <= '1';
            drdy_prev  <= '1';
            drdy_flag  <= '0';
        elsif rising_edge(clk) then
            drdy_sync1 <= drdy_n;
            drdy_sync2 <= drdy_sync1;
            drdy_prev  <= drdy_sync2;

            -- FIX2: Clear drdy_flag when FSM actually starts shifting (ST_SHIFT),
            --        not at CS_SETUP, so a DRDY pulse arriving during CS_SETUP
            --        is not lost. Also clear on ST_CS_SETUP entry is fine but
            --        we move it one state later for safety.
            if drdy_sync2 = '0' and drdy_prev = '1' then
                drdy_flag <= '1';
            elsif state = ST_SHIFT and current_op = OP_ADC_READ then
                drdy_flag <= '0';
            end if;
        end if;
    end process p_drdy;

    -- =========================================================================
    -- Single-process FSM
    -- =========================================================================
    p_fsm : process(clk, rst_n)
        variable v_cmd : std_logic_vector(7 downto 0);
    begin
        if rst_n = '0' then
            state             <= ST_IDLE;
            current_op        <= OP_ADC_READ;
            sclk_r            <= '0';
            cs_n_r            <= '1';
            sdi_r             <= '0';
            tx_shift          <= (others => '0');
            rx_shift          <= (others => '0');
            sclk_phase        <= '0';
            bit_cnt           <= 0;
            gap_cnt           <= 0;
            -- sdo_reg removed (FIX3)
            adc_data_r        <= (others => '0');
            status_byte_r     <= (others => '0');
            data_valid_r      <= '0';
            sample_count_r    <= (others => '0');
            reg_rdata_r       <= (others => '0');
            reg_rdata_valid_r <= '0';

        elsif rising_edge(clk) then

            data_valid_r      <= '0';
            reg_rdata_valid_r <= '0';

            case state is

                -- =============================================================
                -- IDLE: priority → reg_wr > reg_rd > ADC drdy_flag
                -- =============================================================
                when ST_IDLE =>
                    sclk_r     <= '0';
                    cs_n_r     <= '1';
                    sdi_r      <= '0';
                    sclk_phase <= '0';

                    if reg_wr_en = '1' then
                        -- FIX1: WREG command is 0x80|addr (bit7=1), NOT 0x40|addr
                        v_cmd      := std_logic_vector(unsigned'("10000000") or
                                      ("000" & unsigned(reg_addr)));
                        tx_shift   <= v_cmd & x"00" & x"00" & reg_wdata;
                        current_op <= OP_REG_WR;
                        state      <= ST_CS_SETUP;

                    elsif reg_rd_en = '1' then
                        v_cmd      := std_logic_vector(unsigned'("00100000") or
                                      ("000" & unsigned(reg_addr)));
                        tx_shift   <= v_cmd & x"00" & x"00" & x"00";
                        current_op <= OP_REG_RD;
                        state      <= ST_CS_SETUP;

                    elsif drdy_flag = '1' then
                        tx_shift   <= (others => '0');
                        current_op <= OP_ADC_READ;
                        state      <= ST_CS_SETUP;
                    end if;

                -- =============================================================
                -- CS_SETUP: assert CS while SCLK is LOW
                -- SDI is 0 here; the first real bit is driven in the first
                -- rising-edge half-cycle of ST_SHIFT (see below).
                -- =============================================================
                when ST_CS_SETUP =>
                    cs_n_r     <= '0';
                    sclk_r     <= '0';
                    sdi_r      <= tx_shift(FRAME_BITS-1); -- pre-load MSB: gives full
                    sclk_phase <= '0';                    -- 40 ns setup before SCLK rises
                    bit_cnt    <= FRAME_BITS;
                    rx_shift   <= (others => '0');
                    state      <= ST_SHIFT;

                -- =============================================================
                -- SHIFT — correct CPHA=1 timing with registered output pipeline
                --
                -- sclk_phase='0' → RISING edge cycle:
                --   Action this cycle  : sclk_r ← '1', sdi_r ← tx[MSB]
                --   Effect next cycle  : SCLK pin goes HIGH, SDI pin shows tx[MSB]
                --   ADC response       : latches SDI, begins driving new SDO bit
                --   sdo_reg NOT touched here — SDO is not yet valid
                --
                -- sclk_phase='1' → FALLING edge cycle:
                --   Action this cycle  : sclk_r ← '0'
                --                        sdo_reg ← sdo   ← CORRECT: ADC had a
                --                          full cycle to settle SDO after rising edge
                --   Effect next cycle  : SCLK pin goes LOW
                --                        rx_shift updated with sdo_reg next falling edge
                --
                -- Wait — sdo_reg is captured this cycle but rx_shift must wait
                -- until the NEXT falling edge? No: we capture sdo_reg AND shift
                -- rx_shift in the same falling-edge cycle. sdo_reg holds the
                -- value from sdo in THIS cycle (cycle N+1 after rising). The
                -- registered pipeline means:
                --   Cycle N   : rising branch → sclk_r='1'
                --   Cycle N+1 : SCLK pin HIGH; falling branch → sdo_reg=sdo, rx ← sdo_reg_prev... 
                --
                -- CLEANEST SOLUTION: capture sdo directly into rx_shift in
                -- the falling-edge branch. At this point SCLK has been HIGH
                -- for one full clk period on the pin (it was set in cycle N,
                -- appears in cycle N+1, falling branch runs in cycle N+1).
                -- The ADC's SDO prop delay from rising SCLK is typically
                -- 10-20 ns. Our clk period is 40 ns. So sdo is settled well
                -- before the falling-edge branch samples it.
                --
                -- Therefore: sample sdo DIRECTLY into rx_shift in the
                -- falling-edge branch. No sdo_reg pipeline needed.
                -- =============================================================
                when ST_SHIFT =>
                    sclk_phase <= not sclk_phase;

                    if sclk_phase = '0' then
                        -- ---- RISING edge ----
                        -- SCLK goes HIGH next cycle (registered).
                        -- Drive SDI with current MSB — will be stable on
                        -- the pin for the full HIGH period of SCLK.
                        sclk_r <= '1';
                        sdi_r  <= tx_shift(FRAME_BITS-1);
                        -- Do NOT sample sdo here: SCLK not yet HIGH on pin.

                    else
                        -- ---- FALLING edge ----
                        -- SCLK has been HIGH on the pin for one full clk period.
                        -- ADC has responded: sdo is valid and stable.
                        -- Sample directly — no extra pipeline register needed.
                        sclk_r   <= '0';
                        rx_shift <= rx_shift(FRAME_BITS-2 downto 0) & sdo;
                        -- Advance TX for next rising edge
                        tx_shift <= tx_shift(FRAME_BITS-2 downto 0) & '0';
                        bit_cnt  <= bit_cnt - 1;

                        if bit_cnt = 1 then
                            state <= ST_CS_HOLD;
                        end if;
                    end if;

                -- =============================================================
                -- CS_HOLD: SCLK LOW for one cycle, then deassert CS
                -- =============================================================
                when ST_CS_HOLD =>
                    sclk_r <= '0';
                    cs_n_r <= '1';
                    sdi_r  <= '0';
                    state  <= ST_DONE;

                -- =============================================================
                -- DONE
                -- =============================================================
                when ST_DONE =>
                    case current_op is

                        when OP_ADC_READ =>
                            status_byte_r  <= rx_shift(FRAME_BITS-1 downto FRAME_BITS-8);
                            adc_data_r     <= rx_shift(23 downto 0);
                            data_valid_r   <= '1';
                            sample_count_r <= sample_count_r + 1;
                            state          <= ST_IDLE;

                        when OP_REG_WR =>
                            status_byte_r <= rx_shift(FRAME_BITS-1 downto FRAME_BITS-8);
                            adc_data_r    <= rx_shift(23 downto 0);
                            data_valid_r  <= '1';
                            state         <= ST_IDLE;

                        when OP_REG_RD =>
                            tx_shift <= (others => '0');
                            gap_cnt  <= 5;  -- FIX4: was 3 (120ns), now 5 (200ns) for margin
                            state    <= ST_RREG_GAP;

                    end case;

                -- =============================================================
                -- RREG_GAP: CS-high gap (3 cycles = 120 ns > 1 SCLK period)
                -- =============================================================
                when ST_RREG_GAP =>
                    cs_n_r <= '1';
                    sclk_r <= '0';
                    if gap_cnt = 0 then
                        state <= ST_CS_SETUP2;
                    else
                        gap_cnt <= gap_cnt - 1;
                    end if;

                -- =============================================================
                -- Frame 2 (RREG NOP readback) — identical corrected timing
                -- =============================================================
                when ST_CS_SETUP2 =>
                    cs_n_r     <= '0';
                    sclk_r     <= '0';
                    sdi_r      <= tx_shift(FRAME_BITS-1); -- pre-load MSB
                    sclk_phase <= '0';
                    bit_cnt    <= FRAME_BITS;
                    rx_shift   <= (others => '0');
                    state      <= ST_SHIFT2;

                when ST_SHIFT2 =>
                    sclk_phase <= not sclk_phase;

                    if sclk_phase = '0' then
                        sclk_r <= '1';
                        sdi_r  <= tx_shift(FRAME_BITS-1);
                    else
                        sclk_r   <= '0';
                        rx_shift <= rx_shift(FRAME_BITS-2 downto 0) & sdo;
                        tx_shift <= tx_shift(FRAME_BITS-2 downto 0) & '0';
                        bit_cnt  <= bit_cnt - 1;

                        if bit_cnt = 1 then
                            state <= ST_CS_HOLD2;
                        end if;
                    end if;

                when ST_CS_HOLD2 =>
                    sclk_r <= '0';
                    cs_n_r <= '1';
                    sdi_r  <= '0';
                    state  <= ST_DONE2;

                when ST_DONE2 =>
                    reg_rdata_r       <= rx_shift(7 downto 0);
                    reg_rdata_valid_r <= '1';
                    state             <= ST_IDLE;

                when others =>
                    state <= ST_IDLE;

            end case;
        end if;
    end process p_fsm;

    -- =========================================================================
    -- Output assignments
    -- =========================================================================
    sclk            <= sclk_r;
    cs_n            <= cs_n_r;
    sdi             <= sdi_r;
    adc_data        <= adc_data_r;
    status_byte     <= status_byte_r;
    data_valid      <= data_valid_r;
    sample_count    <= std_logic_vector(sample_count_r);
    reg_rdata       <= reg_rdata_r;
    reg_rdata_valid <= reg_rdata_valid_r;
    -- FIX5: busy is a registered signal to avoid combinatorial glitches.
    -- A separate process drives it one cycle after state changes.
    -- For simplicity we keep combinatorial but add the note — in real designs
    -- register this in the FSM process for glitch-free output.
    busy            <= '0' when state = ST_IDLE else '1';

end architecture rtl;
